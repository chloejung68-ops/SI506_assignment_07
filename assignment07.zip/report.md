# Kura MVP Report

## 1.0 Layer, route, and data-model map

Kura has four layers. `app/models.py` defines the `Resource` shape. `app/database.py` owns the
SQLite engine, sessions, database path, table creation, and first-run seed. `app/main.py` owns the
FastAPI application and CRUD route functions. `app/templates/` renders server-side HTML through
Jinja; templates do not access SQLite, and route bodies do not contain HTML.

The seven routes are:

| Route | Purpose | Result |
| :---- | :------ | :----- |
| `GET /` | List all resources or filter by case-insensitive title/topic query `q`. | Renders `list.html` with `resources` and `q`. |
| `GET /resources/new` | Show the shared create form. | Renders `form.html` with `resource=None`, `/resources`, and four types. |
| `POST /resources` | Create one resource from five form fields. | Commits the row and returns `303` to `/`. |
| `GET /resources/{resource_id}` | Show one resource. | Renders `detail.html`, or returns `404 Resource not found`. |
| `GET /resources/{resource_id}/edit` | Show the shared edit form. | Renders `form.html` with the current row and edit action. |
| `POST /resources/{resource_id}/edit` | Replace all five user fields of one resource. | Commits and returns `303` to its detail page. |
| `POST /resources/{resource_id}/delete` | Delete an existing resource. | Commits when present and returns `303` to `/`; a missing row also redirects without a commit. |

The one SQLModel entity is `Resource`:

| Field | Type and behavior |
| :---- | :---------------- |
| `id` | `int \| None`, primary key, assigned by SQLite. |
| `title` | Required `str`; blank strings are not rejected. |
| `resource_type` | Required `str`; the form offers `book`, `article`, `video`, and `website`, but the model does not reject another string. |
| `url` | Optional `str`; an empty form value becomes `None`. |
| `topic` | Optional `str`; an empty form value becomes `None`. |
| `notes` | Optional `str`; an empty form value becomes `None`. |

The filing rule is to classify a resource by the kind of learning material it provides: a book is a
book-length work, an article is an article, a video is video material, and a website is a web-based
resource. The FastAPI documentation is an ambiguous case because it is documentation about a
software library and also a collection of pages. I classify it as `website` because the resource
record points to the official web documentation and the user accesses it as a website rather than
as a single article or book.

## 2.0 Read and write traces

### 2.1 GET trace

For `GET /resources/1`, FastAPI matches `resource_detail` and converts the path segment to an
integer. FastAPI injects one `Session` from `get_session()`; the generator creates a SQLModel
session backed by the SQLite engine and closes it after the request. The route calls
`session.get(Resource, 1)`. If it finds the row, it calls Jinja's `TemplateResponse` with the exact
context `{"resource": resource}` and the template name `detail.html`.

`detail.html` extends `base.html`. The base template supplies the document metadata, linked `Kura`
heading, and content block. The detail template writes the resource title and type, and conditionally
writes the URL, topic, and notes when those values are present. The resulting HTML response is
returned to the browser. A missing row stops at the route with status 404 and the message `Resource
not found`; a non-integer path value stops earlier with FastAPI's default 422 response.

### 2.2 POST trace

For `POST /resources`, FastAPI parses the submitted form fields. `title` and `resource_type` are
required form parameters; `url`, `topic`, and `notes` default to empty strings. The route converts
each empty optional string to `None`, constructs a `Resource`, adds it to the injected SQLModel
session, and calls `commit()`.

The route does not render a template. It returns a `303` response with `Location: /`. The browser
then follows that redirect with `GET /`. The list route reads all rows, or applies a case-insensitive
title/topic filter when `q` is present, and passes the exact context `{"resources": resources,
"q": q}` to `list.html`. The list template extends `base.html`, renders the rows and their detail,
edit, and delete controls, and returns the resulting HTML. Redirect-after-write means a browser
refresh repeats the GET rather than submitting the POST again.

## 3.0 Debugging and diagnostic account

During the persistence slice, the first test reset deleted `resources.db` before each test. The
engine had already opened a connection to the old SQLite file, so the next write failed with
`sqlite3.OperationalError: attempt to write a readonly database`.

The isolating check was the cross-session persistence test: seed reads passed, while the first new
write after the reset failed. That separated the problem from the `Resource` model and from seed
data validation; the responsible interface was the test reset interacting with the persistence
engine. I corrected the reset to call `SQLModel.metadata.drop_all(engine)` and then `init_db()` so
the existing engine remains valid. Ruff, ty, and the full pytest run passed afterward.

This also distinguishes data validation from behavior verification. FastAPI's 422 checks verify
that required form fields are present. The persistence test and later CRUD tests verify behavior:
the application commits a row, reads it in a new session, redirects to the correct page, and keeps
the optional fields as `None`. Neither kind of check proves that a real person found the interface
clear; that is why the manual browser walkthrough remains separate evidence.

## 4.0 Oversight reflection

One corrected assistant proposal was the initial file-deletion reset for SQLite tests. The failing
write isolated the unsafe test setup, and I accepted the correction to an engine-preserving
drop-and-reseed reset. The checks establish route status codes, redirects, stored values, rendered
content, type boundaries, and persistence. They do not establish visual usability, accessibility,
or a person's browser observation.

The MVP deliberately excludes authentication, user accounts, editable resource types, pagination,
sorting, a JavaScript framework, a JSON API, custom validation messages, error pages, and a delete
confirmation page. These are outside the fixed scope, not missing improvements to this submission.

`pyproject.toml` records the Python and package requirements, while `uv.lock` records resolved
versions and hashes. Together they let another environment recreate the same dependency set. The
requirements document fixes the goal, data model, stack, architecture, and exclusions. The approved
specification turns those requirements into exact contexts and route contracts. The build guide
turns the contracts into numbered changes, focused checks, accumulated checks, evidence rows, and
stop boundaries. The evidence matrix connects those sources to the implementation and test
results, so each accepted slice has a traceable reason.

The completed automated evidence is strong, but I remain responsible for interpreting it. I also
completed the ordered GUI walkthrough: the seed list, searches, both create cases, detail pages,
full update, both delete controls, restart persistence, and seed count all behaved as specified.
Step 11 can therefore be accepted and the submission is ready.
