"""Tests for Kura's model and persistence layer."""

from collections.abc import Callable

import anyio.to_thread
import httpx
import pytest
from sqlmodel import Session, SQLModel, select

from app.database import engine, init_db
from app.main import app
from app.models import Resource


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"


@pytest.fixture(autouse=True)
def reset_database(monkeypatch: pytest.MonkeyPatch) -> None:
    """Start each test with the three reference rows."""

    async def run_sync_inline(
        function: Callable[..., object], *args: object, **kwargs: object
    ) -> object:
        del kwargs
        return function(*args)

    monkeypatch.setattr(anyio.to_thread, "run_sync", run_sync_inline)
    SQLModel.metadata.drop_all(engine)
    init_db()


async def get_page(path: str) -> httpx.Response:
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        return await client.get(path)


async def post_form(path: str, data: dict[str, str]) -> httpx.Response:
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        return await client.post(path, data=data, follow_redirects=False)


def test_database_creates_exact_seed_rows() -> None:
    with Session(engine) as session:
        resources = session.exec(select(Resource)).all()

    assert len(resources) == 3
    assert {resource.title for resource in resources} == {
        "Think Python",
        "FastAPI documentation",
        "What Is Computational Thinking?",
    }


def test_initialization_is_idempotent() -> None:
    init_db()

    with Session(engine) as session:
        resources = session.exec(select(Resource)).all()

    assert len(resources) == 3


def test_committed_resource_persists_across_sessions() -> None:
    with Session(engine) as session:
        resource = Resource(title="Session resource", resource_type="video")
        session.add(resource)
        session.commit()
        resource_id = resource.id

    with Session(engine) as session:
        saved_resource = session.get(Resource, resource_id)

    assert saved_resource is not None
    assert saved_resource.title == "Session resource"
    assert saved_resource.resource_type == "video"


@pytest.mark.anyio
async def test_list_route_returns_seed_rows() -> None:
    response = await get_page("/")

    assert response.status_code == 200
    assert "Think Python" in response.text
    assert "FastAPI documentation" in response.text
    assert "What Is Computational Thinking?" in response.text


@pytest.mark.anyio
async def test_list_route_shows_empty_state() -> None:
    with Session(engine) as session:
        session.exec(select(Resource)).all()
        for resource in session.exec(select(Resource)).all():
            session.delete(resource)
        session.commit()

    response = await get_page("/")

    assert response.status_code == 200
    assert "No resources found." in response.text


@pytest.mark.anyio
async def test_search_matches_title_and_topic_without_case_sensitivity() -> None:
    title_response = await get_page("/?q=THINK%20python")
    topic_response = await get_page("/?q=WEB%20DEVELOPMENT")

    assert "Think Python" in title_response.text
    assert "FastAPI documentation" not in title_response.text
    assert "FastAPI documentation" in topic_response.text
    assert 'value="WEB DEVELOPMENT"' in topic_response.text


@pytest.mark.anyio
async def test_search_non_match_and_empty_query() -> None:
    non_match_response = await get_page("/?q=not-found")
    empty_response = await get_page("/?q=")

    assert "No resources found." in non_match_response.text
    assert "Think Python" in empty_response.text
    assert "FastAPI documentation" in empty_response.text
    assert "What Is Computational Thinking?" in empty_response.text


@pytest.mark.anyio
async def test_create_target_redirects_and_persists_optional_values_as_none() -> None:
    response = await post_form(
        "/resources",
        {"title": "New resource", "resource_type": "video", "url": "", "topic": "", "notes": ""},
    )

    assert response.status_code == 303
    assert response.headers["location"] == "/"
    with Session(engine) as session:
        resource = session.exec(select(Resource).where(Resource.title == "New resource")).one()
        assert resource.resource_type == "video"
        assert resource.url is None
        assert resource.topic is None
        assert resource.notes is None

    list_response = await get_page("/")
    assert "New resource" in list_response.text


@pytest.mark.anyio
async def test_create_target_preserves_validation_boundary() -> None:
    missing_title = await post_form("/resources", {"resource_type": "book"})
    missing_type = await post_form("/resources", {"title": "Missing type"})
    blank_title = await post_form("/resources", {"title": "", "resource_type": "other"})

    assert missing_title.status_code == 422
    assert missing_type.status_code == 422
    assert blank_title.status_code == 303


@pytest.mark.anyio
async def test_create_form_has_exact_controls_and_action() -> None:
    response = await get_page("/resources/new")

    assert response.status_code == 200
    assert '<form method="post" action="/resources">' in response.text
    for field_name in ("title", "resource_type", "url", "topic", "notes"):
        assert f'name="{field_name}"' in response.text
    for resource_type in ("book", "article", "video", "website"):
        assert f'value="{resource_type}"' in response.text
    assert 'id="title" name="title" value="" required' in response.text
    assert '<select id="resource_type" name="resource_type" required>' in response.text


@pytest.mark.anyio
async def test_detail_route_shows_selected_resource() -> None:
    first_response = await get_page("/resources/1")
    second_response = await get_page("/resources/2")

    assert first_response.status_code == 200
    assert "Think Python" in first_response.text
    assert "https://greenteapress.com/wp/think-python-3rd-edition/" in first_response.text
    assert "A gentle introduction to programming." in first_response.text
    assert second_response.status_code == 200
    assert "FastAPI documentation" in second_response.text


@pytest.mark.anyio
async def test_detail_route_reports_missing_and_invalid_ids() -> None:
    missing_response = await get_page("/resources/999")
    invalid_response = await get_page("/resources/not-an-id")

    assert missing_response.status_code == 404
    assert "Resource not found" in missing_response.text
    assert invalid_response.status_code == 422


@pytest.mark.anyio
async def test_update_target_replaces_all_fields_and_redirects() -> None:
    response = await post_form(
        "/resources/1/edit",
        {
            "title": "Updated resource",
            "resource_type": "article",
            "url": "",
            "topic": "Updated topic",
            "notes": "Updated notes",
        },
    )

    assert response.status_code == 303
    assert response.headers["location"] == "/resources/1"
    with Session(engine) as session:
        resource = session.get(Resource, 1)
        assert resource is not None
        assert resource.title == "Updated resource"
        assert resource.resource_type == "article"
        assert resource.url is None
        assert resource.topic == "Updated topic"
        assert resource.notes == "Updated notes"

    detail_response = await get_page("/resources/1")
    assert "Updated resource" in detail_response.text
    assert "Updated notes" in detail_response.text


@pytest.mark.anyio
async def test_update_target_preserves_failures_and_validation_boundary() -> None:
    missing_response = await post_form(
        "/resources/999/edit", {"title": "Missing", "resource_type": "book"}
    )
    missing_title = await post_form("/resources/1/edit", {"resource_type": "book"})
    missing_type = await post_form("/resources/1/edit", {"title": "Missing type"})
    accepted_response = await post_form(
        "/resources/1/edit", {"title": "", "resource_type": "unlisted"}
    )

    assert missing_response.status_code == 404
    assert "Resource not found" in missing_response.text
    assert missing_title.status_code == 422
    assert missing_type.status_code == 422
    assert accepted_response.status_code == 303


@pytest.mark.anyio
async def test_edit_form_shows_current_values_choices_and_action() -> None:
    response = await get_page("/resources/3/edit")

    assert response.status_code == 200
    assert '<form method="post" action="/resources/3/edit">' in response.text
    assert 'value="What Is Computational Thinking?"' in response.text
    assert '<option value="article" selected>article</option>' in response.text
    assert 'id="url" name="url" value="https://example.edu/computational-thinking"' in response.text
    assert 'id="topic" name="topic" value="Computational thinking"' in response.text
    assert 'id="notes" name="notes"></textarea>' in response.text
    for resource_type in ("book", "article", "video", "website"):
        assert f'value="{resource_type}"' in response.text


@pytest.mark.anyio
async def test_edit_form_reports_missing_and_invalid_ids() -> None:
    missing_response = await get_page("/resources/999/edit")
    invalid_response = await get_page("/resources/not-an-id/edit")

    assert missing_response.status_code == 404
    assert "Resource not found" in missing_response.text
    assert invalid_response.status_code == 422


@pytest.mark.anyio
async def test_delete_existing_resource_redirects_and_changes_database() -> None:
    response = await post_form("/resources/1/delete", {})

    assert response.status_code == 303
    assert response.headers["location"] == "/"
    with Session(engine) as session:
        assert session.get(Resource, 1) is None
        assert len(session.exec(select(Resource)).all()) == 2


@pytest.mark.anyio
async def test_delete_missing_resource_redirects_without_commit() -> None:
    response = await post_form("/resources/999/delete", {})

    assert response.status_code == 303
    assert response.headers["location"] == "/"
    with Session(engine) as session:
        assert len(session.exec(select(Resource)).all()) == 3


@pytest.mark.anyio
async def test_delete_invalid_id_returns_422_without_changing_database() -> None:
    response = await post_form("/resources/not-an-id/delete", {})

    assert response.status_code == 422
    with Session(engine) as session:
        assert len(session.exec(select(Resource)).all()) == 3


@pytest.mark.anyio
async def test_integration_list_and_search() -> None:
    unfiltered = await get_page("/")
    title_match = await get_page("/?q=THINK%20PYTHON")
    topic_match = await get_page("/?q=WEB%20DEVELOPMENT")
    non_match = await get_page("/?q=not-found")

    assert unfiltered.status_code == 200
    assert "Think Python" in unfiltered.text
    assert "Think Python" in title_match.text
    assert "FastAPI documentation" in topic_match.text
    assert "No resources found." in non_match.text


INTEGRATION_TESTS = (
    "test_integration_list_and_search",
    "test_create_form_has_exact_controls_and_action",
    "test_create_target_redirects_and_persists_optional_values_as_none",
    "test_detail_route_shows_selected_resource",
    "test_edit_form_shows_current_values_choices_and_action",
    "test_update_target_replaces_all_fields_and_redirects",
    "test_delete_existing_resource_redirects_and_changes_database",
    "test_initialization_is_idempotent",
)


if __name__ == "__main__":
    test_paths = [f"{__file__}::{test_name}" for test_name in INTEGRATION_TESTS]
    exit_code = pytest.main(["-q", *test_paths])
    if exit_code == 0:
        print("ALL CRUD TESTS PASSED")
