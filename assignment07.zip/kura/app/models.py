"""SQLModel data models used by Kura."""

from sqlmodel import Field, SQLModel


class Resource(SQLModel, table=True):
    """A learning resource stored by Kura."""

    id: int | None = Field(default=None, primary_key=True)
    title: str
    resource_type: str
    url: str | None = None
    topic: str | None = None
    notes: str | None = None
