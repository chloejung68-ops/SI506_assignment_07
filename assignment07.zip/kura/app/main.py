"""FastAPI application entry point for Kura."""

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlmodel import Session, select

from app.database import get_session, init_db
from app.models import Resource

app = FastAPI(title="Kura")
init_db()
templates = Jinja2Templates(directory="app/templates")
RESOURCE_TYPES = ["book", "article", "video", "website"]


@app.get("/", response_class=HTMLResponse)
def list_resources(
    request: Request,
    q: str = "",
    session: Session = Depends(get_session),
) -> HTMLResponse:
    resources = session.exec(select(Resource)).all()
    if q:
        normalized_query = q.casefold()
        resources = [
            resource
            for resource in resources
            if normalized_query in resource.title.casefold()
            or (resource.topic is not None and normalized_query in resource.topic.casefold())
        ]
    return templates.TemplateResponse(
        request=request,
        name="list.html",
        context={"resources": resources, "q": q},
    )


@app.post("/resources")
def create_resource(
    title: str = Form(...),
    resource_type: str = Form(...),
    url: str = Form(""),
    topic: str = Form(""),
    notes: str = Form(""),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    resource = Resource(
        title=title,
        resource_type=resource_type,
        url=url or None,
        topic=topic or None,
        notes=notes or None,
    )
    session.add(resource)
    session.commit()
    return RedirectResponse(url="/", status_code=303)


@app.get("/resources/new", response_class=HTMLResponse)
def new_resource_form(request: Request) -> HTMLResponse:
    return templates.TemplateResponse(
        request=request,
        name="form.html",
        context={"resource": None, "action": "/resources", "types": RESOURCE_TYPES},
    )


@app.get("/resources/{resource_id}", response_class=HTMLResponse)
def resource_detail(
    resource_id: int,
    request: Request,
    session: Session = Depends(get_session),
) -> HTMLResponse:
    resource = session.get(Resource, resource_id)
    if resource is None:
        raise HTTPException(status_code=404, detail="Resource not found")
    return templates.TemplateResponse(
        request=request,
        name="detail.html",
        context={"resource": resource},
    )


@app.post("/resources/{resource_id}/edit")
def update_resource(
    resource_id: int,
    title: str = Form(...),
    resource_type: str = Form(...),
    url: str = Form(""),
    topic: str = Form(""),
    notes: str = Form(""),
    session: Session = Depends(get_session),
) -> RedirectResponse:
    resource = session.get(Resource, resource_id)
    if resource is None:
        raise HTTPException(status_code=404, detail="Resource not found")

    resource.title = title
    resource.resource_type = resource_type
    resource.url = url or None
    resource.topic = topic or None
    resource.notes = notes or None
    session.add(resource)
    session.commit()
    return RedirectResponse(url=f"/resources/{resource_id}", status_code=303)


@app.get("/resources/{resource_id}/edit", response_class=HTMLResponse)
def edit_resource_form(
    resource_id: int,
    request: Request,
    session: Session = Depends(get_session),
) -> HTMLResponse:
    resource = session.get(Resource, resource_id)
    if resource is None:
        raise HTTPException(status_code=404, detail="Resource not found")
    return templates.TemplateResponse(
        request=request,
        name="form.html",
        context={
            "resource": resource,
            "action": f"/resources/{resource_id}/edit",
            "types": RESOURCE_TYPES,
        },
    )


@app.post("/resources/{resource_id}/delete")
def delete_resource(
    resource_id: int,
    session: Session = Depends(get_session),
) -> RedirectResponse:
    resource = session.get(Resource, resource_id)
    if resource is not None:
        session.delete(resource)
        session.commit()
    return RedirectResponse(url="/", status_code=303)
