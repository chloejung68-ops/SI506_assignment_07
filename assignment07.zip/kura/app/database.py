"""SQLite engine, sessions, and first-run seed data for Kura."""

from collections.abc import Generator
from pathlib import Path

from sqlmodel import Session, SQLModel, create_engine, select

from app.models import Resource

DATABASE_PATH = Path(__file__).parent.parent / "data" / "generated" / "resources.db"
DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)

engine = create_engine(
    f"sqlite:///{DATABASE_PATH}",
    connect_args={"check_same_thread": False},
)


def init_db() -> None:
    """Create the table and seed it once when it is empty."""

    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        if session.exec(select(Resource)).first() is not None:
            return

        resources = [
            Resource(
                title="Think Python",
                resource_type="book",
                url="https://greenteapress.com/wp/think-python-3rd-edition/",
                topic="Python",
                notes="A gentle introduction to programming.",
            ),
            Resource(
                title="FastAPI documentation",
                resource_type="website",
                url="https://fastapi.tiangolo.com/",
                topic="Web development",
                notes="The official FastAPI docs.",
            ),
            Resource(
                title="What Is Computational Thinking?",
                resource_type="article",
                url="https://example.edu/computational-thinking",
                topic="Computational thinking",
            ),
        ]
        session.add_all(resources)
        session.commit()


def get_session() -> Generator[Session, None, None]:
    """Yield one database session for a request."""

    with Session(engine) as session:
        yield session
