"""Kura application package."""
