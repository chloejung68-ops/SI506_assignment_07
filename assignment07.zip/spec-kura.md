# Kura—Specification

**How to use this specification.** Course-provided contracts and completed decisions define the
application without asking you to rewrite settled facts. Review every contract against
`reqs-kura.md`; do not rewrite one merely to use different wording. Do not create `work/kura/` or
implement the application until Sec. 5.1 records approval.

The authority chain is fixed in `reqs-kura.md` Sec. 1.0: the requirements govern this specification,
and the approved specification governs the application. If the artifacts disagree, stop and correct
the specification or implementation rather than changing a supplied requirement.

## 1.0 Purpose and scope

### 1.1 Purpose

Under `reqs-kura.md` Sec. 2.0, Kura gives users a simple way to manage learning resources. It
succeeds when its server-rendered interface supports search and the full CRUD cycle and when
committed changes survive a restart without duplicating the seed records.

### 1.2 Scope boundary

The current iteration stays within the one-entity, server-rendered CRUD MVP governed by
`reqs-kura.md` Sec. 2.0–3.0. Capabilities excluded there belong to a possible future iteration and
do not enter the current specification or implementation.

## 2.0 Layers, templates, and interfaces

### 2.1 Layer responsibilities

The four layers governed by `reqs-kura.md` Sec. 6.0 interact through these interfaces:

```text
browser request
  → FastAPI route in app/main.py
  → SQLModel session using Resource and SQLite
  → route context or 303 redirect
  → Jinja template and HTML response, or the redirected GET
```

The diagram specifies interaction between the layers without restating their responsibilities.

### 2.2 Templates

The template responsibilities are course-provided contracts. Audit them against Sec. 4.0 and 6.0 of
`reqs-kura.md`; do not rename a template or split the shared form.

| Template | Responsibility |
| :------- | :------------- |
| `base.html` | Shared HTML document, linked `Kura` heading, and content block. |
| `list.html` | Search form, resource collection, empty result, and list actions. |
| `form.html` | Shared create/edit fields and submit action. |
| `detail.html` | One resource plus edit, delete, and back-to-list actions. |

`list.html`, `form.html`, and `detail.html` extend `base.html`. Do not add a template for a feature
excluded by `reqs-kura.md` Sec. 3.0. The base supplies UTF-8 and viewport metadata, the linked
`Kura` heading, and one content block.

The shared form labels every user-submitted field governed by `reqs-kura.md` Sec. 4.0. Its controls
apply the required status and choices defined there. The list links to create, detail, and edit
pages. The list and detail pages submit deletion by POST without confirmation.

### 2.3 Exact route–template contexts

These exact names form course-provided interfaces. Audit each route against the template that
consumes its context.

| Rendering route | Template | Exact context |
| :-------------- | :------- | :------------ |
| GET `/` | `list.html` | `resources`: resource sequence; `q`: search string |
| GET `/resources/new` | `form.html` | `resource`: `None`; `action`: `/resources`; `types`: choices from `reqs-kura.md` Sec. 4.0 |
| GET `/resources/{resource_id}` | `detail.html` | `resource`: one `Resource` |
| GET `/resources/{resource_id}/edit` | `form.html` | `resource`: one `Resource`; `action`: `/resources/{resource_id}/edit`; `types`: the four choices |

Write routes render no template and pass no context. A context name changes only when both sides of
the interface and their checks change in the approved specification first.

### 2.4 Persistence contract

The `Resource` model uses the exact fields and defaults in `reqs-kura.md` Sec. 4.0. In
`app/database.py`, create `data/generated/`, store SQLite at `data/generated/resources.db`, and
configure the engine with `check_same_thread=False`.

`init_db()` creates the tables. When the `Resource` table is empty, it constructs fresh model
instances for these exact records, adds them, and commits once:

| Title | Resource type | URL | Topic | Notes |
| :---- | :------------ | :-- | :---- | :---- |
| Think Python | `book` | `https://greenteapress.com/wp/think-python-3rd-edition/` | Python | A gentle introduction to programming. |
| FastAPI documentation | `website` | `https://fastapi.tiangolo.com/` | Web development | The official FastAPI docs. |
| What Is Computational Thinking? | `article` | `https://example.edu/computational-thinking` | Computational thinking | `None` |

SQLite assigns each `id`. Repeated initialization does not duplicate the seed records.
`get_session()` yields one SQLModel `Session` for a request and closes it afterward. `app/main.py`
imports and calls `init_db()` before serving requests.

## 3.0 Route inventory

The seven route contracts are course-provided. Audit them against the exact contexts in Sec. 2.3 and
the data and validation boundaries in `reqs-kura.md` Sec. 4.0.

| Route | Purpose and input | Database/model action | Result and failure | Focused student check |
| :---- | :---------------- | :-------------------- | :----------------- | :-------------------- |
| GET `/` | List resources. Optional query `q`; absent or empty means no filter. | Read all `Resource` rows. For non-empty `q`, keep case-insensitive matches in `title` or non-empty `topic`. | Render `list.html` with exact `resources` and string `q`; absent `q` becomes `""`. No match returns 200 and the empty-list message. | Check status 200, all seed rows, mixed-case title and topic matches, non-match, unfiltered list, retained `q`, and browser output. |
| GET `/resources/new` | Show the create form; no input. | No database action. | Render `form.html` with the exact create context in Sec. 2.3. | Check five field names, four type choices, both required controls, exact action, and browser create flow. |
| POST `/resources` | Create one resource from the five form fields. Title and resource type are required; optional fields default to empty strings. | Normalize empty optional values to `None`, construct a `Resource`, add it, and commit. | Return 303 with `Location: /`; render no template. A missing required field receives default 422; otherwise preserve `reqs-kura.md` Sec. 4.0's validation boundary. | With redirects disabled, check the exact response, each missing required field, blank title, and an unlisted resource type. Read the row in a new session, check optional `None`, and confirm its title on GET `/`. |
| GET `/resources/{resource_id}` | Show one resource from an integer Id. | Read that `Resource` row. | Render `detail.html` with the exact detail context. A missing row returns 404 `Resource not found`; a non-integer Id receives default 422. | Check two existing Ids, exact context, selected content, URL and notes, missing-row status and message, and non-integer status. |
| GET `/resources/{resource_id}/edit` | Show the edit form for an integer Id. | Read that `Resource` row. | Render `form.html` with the exact edit context. A missing row returns 404 `Resource not found`; a non-integer Id receives default 422. | Check exact context and action, current and empty optional values, selected type, all choices, both required controls, missing-row status and message, and non-integer status. |
| POST `/resources/{resource_id}/edit` | Update one resource from an integer Id and the five form fields. | Read the row, replace all five user fields, normalize empty optional values to `None`, add it, and commit. | Return 303 with `Location: /resources/{resource_id}`; render no template. A missing row returns 404 `Resource not found`; a missing required field or non-integer Id receives default 422. | With redirects disabled, check the exact response, each missing required field, blank title, and an unlisted resource type. In a new session, check all five values and optional `None`; check detail display, 404, and non-integer 422. |
| POST `/resources/{resource_id}/delete` | Delete one resource by integer Id. | Delete and commit only when the row exists; do not commit for a missing row. | Return 303 with `Location: /` whether the row exists; render no template. A non-integer Id receives default 422 and changes nothing. | With redirects disabled, check existing, missing, and non-integer responses. In a new session, confirm only the existing row changed the database. |

## 4.0 One-step build and verification plan

Section 4.0 is a course-provided implementation plan. Audit its sequence and controls before
approval. Do not rewrite it or collapse numbered steps.

### 4.1 Rules for every step

Apply the implementation controls in `reqs-kura.md` Sec. 8.0 to every step. Implementation begins
only after Sec. 5.1 records approval, and one prompt authorizes one numbered step.

Step 1 creates the shell files and runs these quality commands:

```bash
uv run ruff format
uv run ruff check
uv run ty check
```

Step 2 creates `test_app.py`. From Step 2 onward, every step also runs `uv run pytest`. The final
step runs `uv run python test_app.py`. A failed check pauses the sequence at the failed contract.

### 4.2 Standalone project setup

After approval, run the setup sequence from the course repository root:

```bash
cd modules/module_07/work
uv init --no-workspace --bare --name kura --python 3.14 kura
cd kura
uv add --frozen "fastapi>=0.115,<0.116" "sqlmodel>=0.0.22" "uvicorn>=0.30" "jinja2>=3.1,<3.2" "python-multipart>=0.0.9"
uv add --dev --frozen "pytest>=8.0" "httpx>=0.27" "anyio>=4.15" "ruff>=0.17.3" "ty>=0.0.95"
uv sync
```

`pyproject.toml` is the setup-created source file. `uv.lock` is reviewed and submitted. `.venv/` is
local and ignored. A `VIRTUAL_ENV` mismatch warning is expected in the devcontainer because uv uses
`work/kura/.venv/`.

Step 1 adds the current Kura quality-tool settings to `pyproject.toml`:

```toml
[tool.ruff]
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I"]

[tool.ruff.lint.flake8-bugbear]
extend-immutable-calls = ["fastapi.Depends", "fastapi.Form", "fastapi.Query", "fastapi.Path"]

[tool.ty.src]
include = ["app", "test_app.py"]
```

### 4.3 Bounded sequence

| Step | Build and authorized source files | Focused check and explanation | Stop boundary |
| :--- | :-------------------------------- | :---------------------------- | :------------ |
| 1. Shell | Create `app/__init__.py`, `app/main.py`, and `app/templates/base.html`; add Sec. 4.2's project configuration to `pyproject.toml`. | Import the app and assert title `Kura`; run the quality commands. Explain why Python and HTML are separate. | No model, database, or route. |
| 2. Model and persistence | Implement `reqs-kura.md` Sec. 4.0 and Sec. 2.4 in `app/models.py`, `app/database.py`, `app/main.py`, and `test_app.py`. | Check table creation, exactly three seed rows, non-duplicating seed, and persistence across sessions; run all checks. Explain shape versus stored row and commit. | No route. |
| 3. List | Implement Sec. 4.4 in `app/main.py`, `base.html`, `list.html`, and `test_app.py`. | Check status 200, seeded rows, exact `resources`/`q`, and empty-list state; run all checks. Trace GET `/` through the session, context, and template. | No search or actions. |
| 4. Search | Implement the GET `/` search behavior in Sec. 3.0 in `app/main.py`, `list.html`, and `test_app.py`. | Check mixed-case title/topic matches, non-match, unfiltered list, and retained `q`; run all checks. Trace `q` through filtering and template context. | No create behavior. |
| 5. Create target | Implement the POST `/resources` row in Sec. 3.0 in `app/main.py` and `test_app.py`. | Check exact 303, persistence, optional `None`, list display, both missing-field 422s, blank title, and unlisted type; run all checks. Explain redirect-after-write. | No create form. |
| 6. Create form | Implement Secs. 2.2–2.3 and Sec. 3.0's GET `/resources/new` row in `app/main.py`, `form.html`, `list.html`, and `test_app.py`. | Check the exact create context, five controls, both required controls, choices, action, and browser flow; run all checks. Trace the form action to the create target. | No detail route. |
| 7. Detail | Implement Sec. 4.5 in `app/main.py`, `detail.html`, `list.html`, and `test_app.py`. | Check selected row, exact context, 404 message, non-integer Id, and two browser Ids; run all checks. Trace an Id through lookup, context, and template. | No edit or delete action. |
| 8. Update target | Implement Sec. 4.6 in `app/main.py` and `test_app.py`. | Check exact 303, persistence, optional `None`, detail display, 404, both missing-field 422s, blank title, and unlisted type; run all checks. Explain replace-all-fields update behavior. | No edit form, link, or GET route. |
| 9. Edit form | Implement Sec. 4.7 in `app/main.py`, `form.html`, `list.html`, `detail.html`, and `test_app.py`. | Check exact edit context, current and empty optional values, selected type, both required controls, action, failures, and browser flow; run all checks. Trace the form action to the update target. | No delete control or route. |
| 10. Delete | Implement Sec. 4.8 in `app/main.py`, `list.html`, `detail.html`, and `test_app.py`. | Check exact redirects, existing, missing, and non-integer Id behavior, database state, and both browser controls; run all checks. Explain why a missing row redirects without a commit. | All seven routes exist; no JavaScript or confirmation page. |
| 11. Integration | Audit Secs. 4.9–4.10; change `test_app.py` only for a named coverage gap. | Check all eight groups and the direct smoke test, then complete the browser, restart, and trace evidence. | No application behavior change; accept only after the human evidence. |

### 4.4 Step 3 list-slice boundary

Step 3 implements only the list portion of the final GET `/` contract in Sec. 3.0. Query filtering
and the search form begin in Step 4. At Step 3, GET `/` injects the session from Step 2, reads every
`Resource`, and renders `list.html` with the exact context names `resources` and `q`. Set `q` to
`""`.

`list.html` extends `base.html` and renders the resources in a table. An empty sequence renders
`No resources found.` The page has no search form or action links. Create, detail, edit, and delete
remain unavailable.

`test_app.py` uses HTTPX `ASGITransport` for in-process requests. In the course container, patch
`anyio.to_thread.run_sync` so short synchronous application operations run inline. Check status 200,
all three seed titles, the exact context contract, and the empty-list state.

Start the server in a separate terminal:

```bash
cd modules/module_07/work/kura
uv run uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/`. Ordinary Python edits reload automatically; template edits appear
after a refresh. Stop the server with Ctrl+C before a configuration change or the final restart
check.

### 4.5 Step 7 detail-slice boundary

Step 7 implements the detail route from Secs. 2.2–2.3 and the corresponding GET row in Sec. 3.0.

GET `/resources/{resource_id}` reads one `Resource` by integer Id. It renders `detail.html` with the
exact context `{"resource": resource}`. A missing row returns status 404 with `Resource not found`.
A non-integer Id receives FastAPI's default status 422 response.

`detail.html` extends `base.html` and shows the title and resource type. It shows the URL, topic,
and notes only when each value is present. It links back to `/`. Resource titles in `list.html` link
to their detail pages. No edit or delete action appears at this boundary.

`test_app.py` checks two existing Ids. For the selected row, it checks the exact context and status
200. It also checks the URL and notes. It checks the missing-row status 404 and message, plus status
422 for a non-integer Id. Inspect two existing Ids in the browser.

### 4.6 Step 8 update-target boundary

Step 8 implements the POST `/resources/{resource_id}/edit` contract in Sec. 3.0. It uses the five
fields and normalization rules from `reqs-kura.md` Sec. 4.0. The title and resource type are
required. The URL, topic, and notes default to empty strings.

The route reads the existing `Resource` first. A missing row returns status 404 with
`Resource not found`. For an existing row, replace all five user fields and normalize each empty
optional string to `None`. Add the resource to the session and commit. Return status 303 with
`Location: /resources/{resource_id}` and render no template.

With redirects disabled, `test_app.py` checks the exact status and `Location` header. It reads the
resource in a new session and checks all five values, including optional `None` values. It also
checks the updated detail display, missing-row status 404 and message, and FastAPI's default status
422 response when either required field is missing. It checks that a blank title and an unlisted
resource type remain accepted. No edit form, edit link, or GET edit route exists at this boundary.

### 4.7 Step 9 edit-form boundary

Step 9 implements the GET `/resources/{resource_id}/edit` contract from Secs. 2.2–2.3 and Sec. 3.0.
The route reads one `Resource` by integer Id. A missing row returns status 404 with
`Resource not found`; a non-integer Id receives FastAPI's default status 422 response. For an
existing row, render `form.html` with exactly these context entries:

| Name | Value |
| :--- | :---- |
| `resource` | The selected `Resource` |
| `action` | `/resources/{resource_id}/edit` |
| `types` | `RESOURCE_TYPES` |

The shared form keeps the Step 6 create behavior. For edit, it submits by POST to `action`, shows
all five current values, and renders `None` optional values as empty controls. It marks the current
resource type as selected and keeps all four type choices. `list.html` and `detail.html` link to
`/resources/{resource_id}/edit`. No delete control or route exists at this boundary.

`test_app.py` checks the exact context and action. It checks the current title and selected type. It
checks all three optional values and all four type choices. It checks the missing-row status 404 and
message, plus status 422 for a non-integer Id. The Step 6 create-form checks still pass.

In the browser, open an edit page from the list. Change all five fields and submit the form. Confirm
the redirected detail page and its edit link.

### 4.8 Step 10 delete boundary

Step 10 implements POST `/resources/{resource_id}/delete` from Secs. 2.2 and 3.0. Read one
`Resource` by integer Id. When the row exists, delete it and commit. When it does not exist, do not
delete or commit. Both cases return status 303 with `Location: /` and render no template. A
non-integer Id receives FastAPI's default status 422 response and does not change the database.

`list.html` and `detail.html` each submit deletion by POST to `/resources/{resource_id}/delete`. Do
not add JavaScript or a confirmation page.

With redirects disabled, `test_app.py` checks the exact status and `Location` header for existing
and missing Ids. It reads database state in a new session after each request. It also checks status
422 for a non-integer Id and confirms that the database did not change. All earlier checks still
pass.

In the browser, delete one resource from the list and another from its detail page. Confirm after
each request that the browser returns to the list and the deleted resource is absent. Record the
Step 10 evidence, confirm that all seven routes exist, and stop before Step 11.

### 4.9 Step 11 integration boundary

First compare the completed project and tests with `reqs-kura.md`, every route and context contract
in this specification, and Sec. 6.1. Change `test_app.py` only when a named contract lacks coverage.
If coverage is complete, make no source change. Do not change application or template behavior in
Step 11.

The final suite covers exactly these eight groups:

1. list and search;
2. create form;
3. create target;
4. detail route;
5. edit form;
6. update target;
7. delete target; and
8. idempotent seeding.

The create and update groups cover both missing required fields. They also confirm that blank titles
and unlisted resource types remain accepted at the current validation boundary.

The direct-run block includes the eight corresponding test functions. It resets the database before
each function and prints `ALL CRUD TESTS PASSED` only after every function succeeds.

Run the final automated sequence:

```bash
uv run ruff format
uv run pytest
uv run ruff check
uv run ty check
uv run python test_app.py
```

Inspect formatter changes and the complete Step 11 diff before acceptance. Repair any change to a
file other than `test_app.py` or any test change that alters application behavior. Record the
coverage decision and exact command results in the Step 11 row of `evidence.md`.

The automated results do not complete Step 11. Complete the human verification in Sec. 4.10. Record
the concise browser and restart results in the Step 11 evidence row and final integration narrative.
Put the complete read and write traces in `report.md`. An AI assistant must not claim your
observations. Accept Step 11 only after all of that evidence passes.

### 4.10 Step 11 human-verification boundary

From the Kura project directory, start the app in a separate terminal:

```bash
uv run uvicorn app.main:app --reload
```

Complete this browser walkthrough in order:

1. Open `/` and confirm the three seed rows.
2. Search a title with different letter case.
3. Search a topic with different letter case.
4. Search for a term with no match and confirm the empty state.
5. Create a resource with all fields populated.
6. Create another resource with empty optional fields.
7. Open two different detail pages.
8. Edit one resource and confirm all five changed values.
9. Delete one resource from the list.
10. Delete another resource from its detail page.

Stop Uvicorn with Ctrl+C. Start it again with the same command. Confirm that committed changes
remain and that startup did not add another copy of the three seed rows.

Trace one GET from its route to the session and model. Continue through the exact template context,
Jinja template, and returned HTML. Trace one POST from submitted values to the model and commit.
Continue through the 303 redirect, following GET, context, and returned HTML. Put both full traces
in `report.md`.

An AI assistant may guide the walkthrough and traces. It must not claim the human observations.
Record the concise browser and restart results in the Step 11 evidence row and final integration
narrative. Accept Step 11 only after the evidence row, narrative, and report traces are complete.

## 5.0 Review, evidence, and approval

### 5.1 Document review

Use this course-provided prompt before Step 1:

```text
Review spec-kura.md without building the app. Check it against reqs-kura.md. Report blocking
ambiguity, internal inconsistency, route–template mismatch, missing verification, and scope drift
separately from optional wording improvements. Do not edit application files.
```

**Review result.** The review found no blockers. It identified no ambiguity or internal
inconsistency. It also found no route–template mismatch, missing verification, or scope drift.

The purpose and scope agree with `reqs-kura.md`. So do the data model, runtime stack, and
architecture. The seven-route inventory and exact template contexts match the requirements. All
eleven build steps now contain the six required controls. The verification plan checks the complete
validation boundary. The future-iteration entry in Sec. 6.3 remains outside the current
implementation and does not block approval.

**Approval decision.** **Approved for implementation.** No blocking decision remains. The
specification supplies the contracts needed to build and verify Kura without adding an excluded
feature or making an unresolved design choice.

### 5.2 One evidence record per step

Keep the approved specification unchanged during implementation. Record the specification-review
summary and one row for each attempted step in `evidence.md`, using the matrix required by the
assignment. The diff, command output, browser observation, and explanation support the row. A repair
remains inside the same row and reruns its checks.

### 5.3 Implementation handoff

Use this course-provided prompt to authorize exactly one approved step:

```text
Implement only Step N in ../spec-kura.md. First read ../reqs-kura.md and the step's referenced
contracts. Change only its authorized source files. Run its focused check, every applicable earlier
check, and the named quality commands. Report the diff, evidence, explanation, and stop condition.
Stop before Step N+1.
```

## 6.0 Definition of done and open decisions

### 6.1 Definition of done

These course-provided conditions remain unchecked until their evidence exists:

- [ ] Every capability in `reqs-kura.md` Sec. 2.0 works; no Sec. 3.0 exclusion was added.
- [ ] All seven routes passed their focused checks and the exact Sec. 2.3 contexts agree.
- [ ] Every step has an accepted row in `evidence.md` and a confirmed stop boundary.
- [ ] `evidence.md` has the approved specification review and all three required narratives;
   `report.md` has all four required products.
- [ ] `uv run ruff format`, `uv run ruff check`, and `uv run ty check` complete successfully.
- [ ] `uv run pytest` and `uv run python test_app.py` complete successfully.
- [ ] The browser CRUD/search walkthrough and restart-persistence check pass.
- [ ] You can trace one read, one write, and the purpose of every route and template.

### 6.2 Resolved decisions

| Decision | Resolution |
| :------- | :--------- |
| Treat deletion of a missing row as an error? | No. Make no change and redirect to `/`. |

No unresolved decision blocks this MVP.

### 6.3 Future iterations

The exclusions in `reqs-kura.md` Sec. 3.0 remain outside this build.

| Future idea | Why it remains outside this iteration |
| :---------- | :------------------------------------ |
| Paginate a long resource list. | `reqs-kura.md` Sec. 3.0 explicitly excludes pagination from this iteration. |
