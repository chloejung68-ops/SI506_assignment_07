# Kura Evidence

## 1.0 Specification review confirmation

**Confirmation date:** 2026-11-09

I read `spec-kura.md` Sec. 5.1 before implementation. The course-provided review found no
blocking ambiguity, internal inconsistency, route–template mismatch, missing verification, or
scope drift. The checked-in specification records **Approved for implementation** and says that no
blocking decision remains. This is the course-provided review and approval, not my own replacement
decision.

## 2.0 Implementation evidence matrix

The implementation followed the numbered boundaries in `spec-kura.md` Sec. 4.3. A repair stayed in
the same step and its checks were rerun.

| Step | Authorized versus actual files | Focused and quality checks | Accumulated check | Decision | Stop confirmed |
| :--- | :---------------------------- | :------------------------- | :---------------- | :------- | :------------- |
| `1` | Authorized: `app/__init__.py`, `app/main.py`, `app/templates/base.html`, `pyproject.toml`; actual: same. | App import and `Kura` title assertion passed; Ruff format, Ruff check, and ty passed. Python and HTML were kept separate. | Not applicable. | `accept` | `yes` |
| `2` | Authorized: `app/models.py`, `app/database.py`, `app/main.py`, `test_app.py`; actual: same. | Table creation, three seed rows, idempotent initialization, and cross-session persistence passed; Ruff format/check and ty passed. Test reset was corrected from file deletion to `drop_all` after a readonly SQLite failure. | pytest: 3 passed. | `accept` | `yes` |
| `3` | Authorized: `app/main.py`, `base.html`, `list.html`, `test_app.py`; actual: same. | GET `/` returned 200 with all seed titles and the empty-list message; HTTPX ASGITransport and AnyIO inline thread patch were added; quality checks passed. | pytest: 5 passed. | `accept` | `yes` |
| `4` | Authorized: `app/main.py`, `list.html`, `test_app.py`; actual: same. | Mixed-case title/topic search, empty query, non-match, and retained `q` passed; quality checks passed. | pytest: 7 passed. | `accept` | `yes` |
| `5` | Authorized: `app/main.py`, `test_app.py`; actual: same. | POST create returned exact 303 `/`, persisted optional `None`, checked both missing fields, blank title, and unlisted type; quality checks passed. | pytest: 9 passed. | `accept` | `yes` |
| `6` | Authorized: `app/main.py`, `form.html`, `list.html`, `test_app.py`; actual: same. | Create form had five controls, four choices, exact action, and required title/type controls; create flow tests passed; quality checks passed. | pytest: 10 passed. | `accept` | `yes` |
| `7` | Authorized: `app/main.py`, `detail.html`, `list.html`, `test_app.py`; actual: same. | Two detail records, URL/notes, missing-row 404, and non-integer 422 passed; quality checks passed. | pytest: 12 passed. | `accept` | `yes` |
| `8` | Authorized: `app/main.py`, `test_app.py`; actual: same. | Update replaced all five fields, returned exact 303, persisted `None`, and covered 404/422 and validation-boundary behavior; quality checks passed. | pytest: 14 passed. | `accept` | `yes` |
| `9` | Authorized: `app/main.py`, `form.html`, `list.html`, `detail.html`, `test_app.py`; actual: same. | Edit context, action, current values, selected type, empty optional value, choices, 404, and 422 passed; quality checks passed. | pytest: 16 passed. | `accept` | `yes` |
| `10` | Authorized: `app/main.py`, `list.html`, `detail.html`, `test_app.py`; actual: same. | Existing, missing, and non-integer delete behavior and both POST controls passed; quality checks passed. | pytest: 19 passed. | `accept` | `yes` |
| `11` | Authorized application change: none; authorized test change only for named coverage gaps; actual: only `test_app.py` was extended with eight integration targets and the direct-run block. | Final automated sequence passed: Ruff format, pytest (20 passed), Ruff check, ty, and `python test_app.py` printed `ALL CRUD TESTS PASSED`. The human browser walkthrough covered the seed list, title/topic search, empty results, both create cases, two detail pages, full update, list delete, detail delete, restart persistence, and non-duplicating seeds. | Accumulated pytest: 20 passed; direct run: 8 passed; human walkthrough passed. | `accept` | `yes` |

## 3.0 Representative evidence narratives

### 3.1 Setup or persistence

Step 2 authorized `app/models.py`, `app/database.py`, `app/main.py`, and `test_app.py`, and those
were the only actual files changed in that step. The focused checks created the table, verified the
three exact seed records, called `init_db()` twice without duplication, and read a committed record
from a new session. The first reset approach deleted the SQLite file while the SQLAlchemy engine
still held a connection; the persistence test isolated that problem with `attempt to write a
readonly database`. I corrected the test reset to drop and recreate the metadata through the same
engine. Ruff format/check, ty, and the accumulated pytest result of 3 passed then succeeded. I
accepted the step because the model/database contract and persistence evidence passed, and stopped
before adding a route.

### 3.2 One interface

Step 6 authorized `app/main.py`, `app/templates/form.html`, `app/templates/list.html`, and
`test_app.py`; the actual files matched. The review observation was that the shared form must point
to the route-provided `action`, so the create form uses `/resources` while leaving the form reusable
for the later edit route. The focused test checked the five field names, four choices, exact POST
action, and required title and resource-type controls. The accumulated suite reached 10 passed with
Ruff format/check and ty also passing. The decision was `accept`, and the stop condition was
confirmed before the detail route.

### 3.3 Final integration

Step 11 authorized no application or template behavior change and allowed `test_app.py` changes only
for named coverage gaps. The actual final change was limited to the eight integration targets and
the direct-run block in `test_app.py`. Automated evidence included 20 passing pytest tests, eight
passing direct-run tests, `ALL CRUD TESTS PASSED`, and a real Uvicorn HTTP walkthrough. The human
browser walkthrough then confirmed the three seed rows, mixed-case title and topic searches, the
empty result state, creation with populated and empty optional fields, two detail pages, all five
updated values, deletion from the list, deletion from a detail page, persistence after restart, and
non-duplicating seeds. The decision is `accept`, and the stop boundary is confirmed.
